#include <stdio.h>
#include <math.h>
void myPrintHelloMake(void);
