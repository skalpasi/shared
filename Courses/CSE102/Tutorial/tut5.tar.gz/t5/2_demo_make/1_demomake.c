
#include "3_demomake.h"

int main() 
{
	  // call a function in another file
	  myPrintHelloMake();
	  printf("%f\n",sqrt(9));
	  return(0);
}
