#include<stdio.h>
int sum(int a, int b)
{
	return a+b;
}
int main()
{
	int a=4,b=5;
	printf("%d\n-------------------\n",sum(a,b));
	return 0;
}
