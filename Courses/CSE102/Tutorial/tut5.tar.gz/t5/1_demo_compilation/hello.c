#include <stdio.h>
#define add(a,b) (a+b)
// comment 1
int main()
{
	// comment 2
	int a=5,b=3;
	printf("Output is: %d\n", add(a,b));
	return 0;
	// comment 3
}
