#include<stdio.h>
#include<stdlib.h>
typedef struct data{
	char a;
	int b;
	double f;
}data_t;

void bar(int arg)
{
	int *p=NULL;
	if(arg){
		p= malloc(sizeof(int)*4);
	}
	*p=42;
	printf("%d\n",*p);
	free(p);
}

void foo()
{
	data_t* allocation = malloc(sizeof(data_t*));
	bar(1);
	//free(allocation);
}

void fo()
{
	bar(1);
}

int main()
{
	fo();
	foo();
	return 0;
}
