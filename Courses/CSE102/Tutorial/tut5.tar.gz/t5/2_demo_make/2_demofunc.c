#include <stdio.h>
#include "3_demomake.h"

void myPrintHelloMake(void) 
{

	  printf("Hello makefiles!\n");

	    return;
}
