// comments
#include <stdio.h>
int main()
{
	int n;
	do{
		printf("Enter a positive integer: ");
		scanf("%d",&n);
	}while(n<0);
	int fact=1;
	for(int i=1; i<= n; i++){
		fact=fact*i;
	}
	printf("%d!= %d\n", n,fact);
	return 0;
}
