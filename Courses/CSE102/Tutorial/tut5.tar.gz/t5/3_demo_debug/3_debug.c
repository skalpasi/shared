#include <stdio.h>
int main()
{
	int *ip,*pa;
	int arr[10]={2,4,1};
	int x=&arr[2];
	pa=(arr+2);
	ip=x;
	printf("%d\n",*pa);
	printf("%d\n",*ip);
	return 0;
}
